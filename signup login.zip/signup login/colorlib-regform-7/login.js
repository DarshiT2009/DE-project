document.getElementById("switch-to-signup").addEventListener("click", function(event) {
    event.preventDefault();
    window.location.href= "signup.html";
})

