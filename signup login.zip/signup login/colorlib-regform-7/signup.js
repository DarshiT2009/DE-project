document.getElementById("switch-to-login").addEventListener("click", function(event) {
  event.preventDefault();
  window.location.href = "login.html";
})
